#!/sbin/sh

# Creating the initiation for ui_print from within a .sh file to recovery ui
# this was created by Chainfire. Not really needed here but good fun!

# get file descriptor for output
OUTFD=$(ps | grep -v "grep" | grep -o -E "update_binary(.*)" | cut -d " " -f 3);

ui_print() {
  if [ $OUTFD != "" ]; then
    echo "ui_print ${1} " 1>&$OUTFD;
    echo "ui_print " 1>&$OUTFD;
  else
    echo "${1}";
  fi;
}

# --- actual script for changing the build.prop dpi setting ---

#Use eiter $1 for input from updater-script or directly from here
#like in this case

#DPI=$1
DPI=210

ui_print "  Setting lcd_density in build.prop to $DPI";

#changing build.prop though a build.prop1. Thanks to Backhead92 for this part.
cat /system/build.prop | sed -e "s/ro.sf.lcd_density=.*./ro.sf.lcd_density=$DPI/" > /system/build.prop1
rm /system/build.prop
mv /system/build.prop1 /system/build.prop
